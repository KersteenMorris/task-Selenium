# Guru99 Telecom Automation

Selenium + TestNG automation for https://demo.guru99.com/telecom, built with Java and the Page Object Model (POM).

## What I did

I automated two test cases that run in sequence.

**Test Case 1: Add Customer**
- Opened the telecom site and the left-side menu, then clicked **Add Customer**.
- Selected **Done** for Background Check.
- Filled in the customer data: First Name `kersten`, Last Name `moris`, Email `kerstenmoris552@gmail.com`, Address `Cairo`, Mobile `01234567890`.
- Clicked **Submit**, then captured the generated **Customer ID** and asserted it.

**Test Case 2: Add Tariff Plan to Customer**
- Opened **Add Tariff Plan to Customer** from the menu.
- Entered the Customer ID captured in Test Case 1 and clicked **Submit**.
- Selected a tariff plan and clicked **Submit** again.
- Asserted that the tariff plan was assigned successfully.

## How it is built

- **Pages** (`pages/`): `BasePage` (WebDriver and explicit waits), `TelecomHomePage`, `AddCustomerPage`, `AddTariffPlanPage`.
- **Tests** (`tests/`): `TelecomTest`. Test Case 2 depends on Test Case 1 and uses its Customer ID.
- **Config:** `pom.xml` with Selenium Java, TestNG and WebDriverManager.

## How to run

Requirements: JDK 11+, Maven, Google Chrome.

```bash
mvn clean test
```

For headless mode: `mvn clean test -Dheadless=true`

Reports are generated in `target/surefire-reports/`.
